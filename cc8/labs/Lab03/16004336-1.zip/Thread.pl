#!/usr/bin/perl -w
use strict;
use Socket;
use warnings;
use threads;
use bytes;

my $server = shift || "localhost";
my $port = shift || 1855;
my $proto = getprotobyname('tcp');
my $content = "";
socket(SOCKET, PF_INET, SOCK_STREAM, $proto) or die "Can't open socket $!\n";
setsockopt(SOCKET, SOL_SOCKET, SO_REUSEADDR, 1) or die "Can't set socket option to SO_REUSEADDR $!\n";
bind( SOCKET, pack_sockaddr_in($port, inet_aton($server))) or die "Can't bind to port $port! \n";
listen(SOCKET, 5) or die "listen: $!";
print "> Server started on port $port\n";

#sub threaded_task {
#    threads->create(sub { 
#        my $thr_id = threads->self->tid; # GET ID THREAD
#        my $randNum = int(rand(4))+2;
#        print "Starting thread $thr_id (will wait $randNum seg)\n";
#        sleep $randNum; # PROCESS
#        print "Ending thread $thr_id\n";
#        threads->detach(); #END THREAD
#    });
#}

while (1)
{
    accept(SOCKET_CLIENT_NEW, SOCKET);
    my $socket_cliente = <SOCKET_CLIENT_NEW>;
    my $content = "";

    my @request = split(/\s+/, $socket_cliente);
    my $metodo = $request[0];

    if($metodo eq "GET"){
        my $path_request = $request[1];
        my @full_path = split(/\/+/, $path_request);
        my $name_file = $full_path[1];

        if($name_file eq ""){
            $name_file = "index.html";
        }

        my @file_mime = split(/\.+/, $path_request);
        my $mime_request = $file_mime[1];

        #default value
        my $mime_type = "text/html";

        if($mime_request eq "png"){
            $mime_type = "image/png";
        } elsif($mime_request eq "css"){
            $mime_type = "text/css";
        }

        if(open(my $file_content, '<', $name_file)){
            while (my $linea = <$file_content>) {
                $content = $content . $linea;
            }
            print SOCKET_CLIENT_NEW "HTTP/1.1 200 OK\r\n";
            print SOCKET_CLIENT_NEW "Date: Guatemala hoy\r\n";
            print SOCKET_CLIENT_NEW "Content-Type: $mime_type\r\n";
            print SOCKET_CLIENT_NEW "Connection: keep-alive\r\n";
            my $length_line = bytes::length($content);
            print SOCKET_CLIENT_NEW "Content-Length: $length_line\r\n"; 
            print SOCKET_CLIENT_NEW "\r\n";
            print SOCKET_CLIENT_NEW $content;
            close $file_content;
            close SOCKET_CLIENT_NEW;
            print "> Connection close\n";
        }
    } elsif($metodo eq "POST"){

    }

    #threaded_task();
    #sleep 1;
}