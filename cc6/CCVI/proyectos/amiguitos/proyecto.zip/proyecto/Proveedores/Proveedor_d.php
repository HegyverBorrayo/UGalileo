<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Proveedor eliminado</h1>
          <?php
                        $sql1 = "update Activo set idProveedor = 1 where idProveedor = " . $_POST["idProveedor"];	
                        $resultado1 = mysqli_query($con, $sql1);

			$sql1 = "delete from Proveedor where idProveedor = " . $_POST["idProveedor"];	
			$resultado1 = mysqli_query($con, $sql1);
		?>
        <a href = "Proveedor_busqueda.php">nueva busqueda</a>
        </div>
 

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

