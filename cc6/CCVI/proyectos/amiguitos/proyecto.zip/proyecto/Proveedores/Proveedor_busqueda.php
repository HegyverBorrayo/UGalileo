<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Buscar Proveedor</h1>

        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->
        <div>
            <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row width="100%" align="center">
                    <div class="col-lg-7">
                        <div class="p-5">
                        <div class="text-left">
                            <h1 class="h5 text-gray-900 mb-4">Ingrese los datos a buscar...</h1>
                        </div>
                        <form name="datos" method="post" action="ListProveedor.php" onsubmit="return verifica_formulario(this);">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" name="nombre" placeholder="Razón Social del Proveedor" >
                            </div>
                            <label >Días de crédito:</label>
                            <div class="form-group row">                               
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="number" min="0" class="form-control form-control-user" name="minimo" placeholder="Mínimo" required value="0">
                                    <h6 align ="center" class="h8 text-gray-600 mb-4">Mínimo</h6>
                                </div>
                                <div class="col-sm-6">
                                    <input type="number" min="0" class="form-control form-control-user" name="maximo" placeholder="Máximo" required value ="9999">
                                    <h6 align ="center" class="h8 text-gray-600 mb-4">Máximo</h6>
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Buscar">
                        </form>               
                    </div>
                </div>
            </div>
            </div>

        </div>
        <!-- Termina Formulario  -->

       

      <!-- End of Main Content -->
      <script type="text/javascript">

        function verifica_formulario(pform) {
        if (pform.maximo.value < pform.minimo.value) {
                alert('Rango de dias de credito invalido...');
                pform.maximo.focus();
                return false;
            }
            return true;
        }
        </script>
<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

