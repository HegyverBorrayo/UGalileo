<?PHP
include("../bd/inicia_conexion.php");

$sql = "select * from Proveedor";
$sql = $sql . " where idProveedor = " . $_POST["idProveedor"];
$resultado = mysqli_query($con, $sql);
while ($fila = mysqli_fetch_array($resultado)) {
    $nombre = $fila["nombre"];
    $dias = $fila["diasCredito"];	
}
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Editar Proveedor</h1>

        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->
        <div>
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row width="100%" align="center">
                        <div class="col-lg-7">
                            <div class="p-5">
                            <div class="text-left">
                                <h1 class="h5 text-gray-900 mb-4">Edite los campos que desee</h1>
                            </div>
                            <form name="datos" method="post" action="Proveedor_u.php">
                                <div class="col-sm-6">
                                    <input type="hidden" name="idProveedor" value="<?=$_POST["idProveedor"];?>">	
                                    <label align="left" >Razón Social:</label>
                                    <input type="text" class="form-control form-control-user" name="nombre" value="<?=$nombre;?>" required>
                                    <br>
                                    <label >Días de crédito:</label>
                                    <input type="number" min="0" class="form-control form-control-user" name="dias" value="<?=$dias;?>" required>
                                    <br>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Editar Proveedor">
                            </form>               
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Termina Formulario  -->
      <!-- End of Main Content -->

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

