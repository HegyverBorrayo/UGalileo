<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Marca eliminado</h1>
          <?php

          
                        $sql1 = "update Activo set idMarca = 1 where idMarca = " . $_POST["idMarca"];	
                        $resultado1 = mysqli_query($con, $sql1);

			$sql1 = "delete from Marca where idMarca = " . $_POST["idMarca"];	
			$resultado1 = mysqli_query($con, $sql1);
		?>
        <a href = "Marca_busqueda.php">nueva busqueda</a>
        </div>
 

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

