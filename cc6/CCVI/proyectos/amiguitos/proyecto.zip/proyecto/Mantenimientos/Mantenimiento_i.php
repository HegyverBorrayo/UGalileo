<?php
	include("../bd/inicia_conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<div align="center">
		<?php

                $sql = "insert into Mantenimiento (fechaInicio,idEstadoActivo, idActivo) values (NOW(),1," . $_POST["idActivo"] . ")";
                $resultado = mysqli_query($con, $sql);	
               // echo $sql;
                if($resultado){
                   // echo "funciono";
                   header("location:ListMantenimiento.php?variable=1");
                }else{
                    echo "no funciono";
                }

				//echo "Interes Registrado con éxito.<br /><a href='index.html'>Continuar</a>";		
			
		?>
	</div>
</body>
</html>
<?php 
	include("../bd/fin_conexion.php");
?>