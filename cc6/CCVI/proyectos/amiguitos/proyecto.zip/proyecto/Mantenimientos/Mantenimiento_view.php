<?PHP
include("../bd/inicia_conexion.php");

$sql = "select * from Mantenimiento";
$sql = $sql . " where idMantenimiento = " . $_POST["idMantenimiento"];
$resultado = mysqli_query($con, $sql);
while ($fila = mysqli_fetch_array($resultado)) {
    $idActivo = $fila["idActivo"];
    $costo = $fila["costo"];
    $idEstado = $fila["idEstadoActivo"];
}
include("../includes/header.php");
?>


        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Cerrar Mantenimiento</h1>

        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->
        <div>
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row width="100%" align="center">
                        <div class="col-lg-7">
                            <div class="p-5">
                            <div class="text-left">
                                <h1 class="h5 text-gray-900 mb-4">
                                  <?php 
                                  if($idEstado == "1"){
                                    echo "Para poder cerrar el mantenimiento rellene el siguiente formulario:";
                                  }else{
                                    echo "Detalles del Mantenimiento";
                                  }
                                  
                                  ?>
                                  </h1>
                            </div>
                            <form name="datos" method="post" action="Mantenimiento_u.php" onsubmit="return verifica_formulario(this);">
                                <div class="col-sm-6">
                                <input type="hidden" name="idMantenimiento" value="<?=$_POST["idMantenimiento"];?>">

                                <input type="hidden" name="idActivo" value="<?=$idActivo;?>">
                                  <label >Activo:</label>
                                  <select class="browser-default custom-select" name="idActivo" disabled>
                                    <option value="-1" selected></option>
                                    <?php 
                                      $sql = "select *from Activo where idEstado = 2";
                                      $resultado = mysqli_query($con, $sql);
                                      while ($fila = mysqli_fetch_array($resultado)) {
                                        $seleccionado = "";
                                        if ($idActivo == $fila["idActivo"]){
                                          $seleccionado = "selected";
                                        }
                                        echo "<option value='" . $fila["idActivo"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                      }
                                    ?>
                                  </select>
                                  <br>
                                  <br>
                                  <label >Costo del mantenimiento (Q):</label>
                                  <input type="number" min="0" class="form-control form-control-user" name="costo" placeholder="Costo del mantenimiento (Q)" value="<?=$costo;?>"  required <?php if($idEstado == "2"){ echo "disabled";} ?> >
                                  <br>
                                </div>
                                <?php 
                                  if($idEstado == "1")
                                  { 
                                    echo "<input type=\"submit\" class=\"btn btn-primary\" value=\"Cerrar Mantenimiento\">";                                 
                                  } 
                                  
                                  ?>
                                
                            </form>                  
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Termina Formulario  -->

       

      <!-- End of Main Content -->

<script type="text/javascript">
	function verifica_formulario(pform) {
		if (pform.idDepartamento.value == -1) {
			alert('Debe de seleccionar un departamento');
			pform.idDepartamento.focus();
			return false;
		}
    if (pform.idPuesto.value == -1) {
			alert('Debe de seleccionar un puesto');
			pform.idPuesto.focus();
			return false;
		}
    if (pform.idOficina.value == -1) {
			alert('Debe de seleccionar una oficina');
			pform.idOficina.focus();
			return false;
		}
		return true;
	}
</script>
<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

