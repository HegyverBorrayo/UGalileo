<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Mantenimiento Editado</h1>
          <?php
            $sql = "begin transacction";
            $resultado = mysqli_query($con, $sql);

            $sql = "update Mantenimiento set";
            $sql = $sql . " costo = ". $_POST["costo"];
            $sql = $sql . ", fechaFinal = NOW()";
            $sql = $sql . ", idEstadoActivo = 2";
            $sql = $sql . " where idMantenimiento = ". $_POST["idMantenimiento"] ."";	
            //echo $sql;		
            $resultado = mysqli_query($con, $sql);

            $sql = "commit";
            $resultado = mysqli_query($con, $sql);	

            $sql = "update Activo set";
            $sql = $sql . " idEstado = 3";
            $sql = $sql . " where idActivo = ". $_POST["idActivo"] ."";		
           // echo $sql;
            $resultado = mysqli_query($con, $sql);

            
          ?>
        <a href = "Mantenimiento_busqueda.php">nueva busqueda</a>
        </div>
        <!-- /.container-fluid -->
      <!-- End of Main Content -->

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

