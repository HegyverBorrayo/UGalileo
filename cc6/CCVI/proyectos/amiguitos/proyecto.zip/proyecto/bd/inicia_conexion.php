<?php 
	$con = mysqli_connect("127.0.0.1", "root", "");
	if (!$con) {
		die('Could not connect: '. mysql_connect_error());
	}
	mysqli_select_db($con, "ActivosFijos");
?>