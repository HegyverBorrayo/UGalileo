<?php
  include("../bd/inicia_conexion.php");
  include("../includes/header.php");
?>
  

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->

          <h1 class="h3 mb-2 text-gray-800">Usuarios</h1>
         

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
          <?php
            if (!empty($_GET)) {
              $variable=$_GET['variable'];
              if($variable ==1){
               $_POST["usuario"] = "";
              echo '<div class="card-header py-3">
                      <h6 class="m-0 font-weight-bold text-primary">USUARIO CREADO CON EXITO!</h6>
                    </div>';
              }
            }            
          ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Usuario</th>
                      <th>Rol</th>
                      <th>Modificar</th>
                      <th>Eliminar</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Id</th>
                      <th>Usuario</th>
                      <th>Rol</th>
                      <th>Modificar</th>
                      <th>Eliminar</th>
                    </tr>
                  </tfoot>
                  <tbody>
                       <?php 
                        
                                $sql = "select  u.idUsuario, u.usuario, r.nombre";   
                                $sql = $sql . " FROM Usuario u inner join Rol r on u.idRol = r.idRol";
                                $sql = $sql . " WHERE u.usuario like '%" . $_POST["usuario"] . "%'"; 
                                if(!empty($_POST["idRol"])){
                                  if($_POST["idRol"] != "-1"){
                                    $sql = $sql . " and u.idRol = " . $_POST["idRol"];
                                  }
                                }

                                //echo $sql;
                                $resultado = mysqli_query($con, $sql);
                                while ($fila = mysqli_fetch_array($resultado)) {
                                  
                                    echo "<tr>";
                                    if ($_SESSION["idRol"] == "3" || $_SESSION["idRol"] == "2"){
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                    }else{
                                    echo "<td>" . $fila["idUsuario"] . "</td>";
                                    echo "<td>" . $fila["usuario"] . "</td>";
                                    echo "<td>" . $fila["nombre"] . "</td>";
                                    echo "<td align = 'center'>";
                                    echo "<a href = 'javascript:fun_view(" . $fila["idUsuario"] . ");'>";   
                                    echo "<i class=\"fas fa-pencil-alt\"></i>";                                                   
                                    echo "</td>";
                                    echo "<td align = 'center'>";
                                    echo "<a href = 'javascript:fun_delete(" . $fila["idUsuario"] . ");'>";
                                    echo "<i class=\"fas fa-trash-alt\"></i>";
                                    echo "</td>";
                                    echo "</tr>";   
                                    }                                
								                }
							            ?>                
                  </tbody>
                </table>
              </div>
            </div>
          </div>

            


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

  <form name = 'fdelete' method = 'post' action = 'Usuario_d.php'>
            <input  type = "hidden" name = "idUsuario">                    
    </form>    
    <form name = 'fview' method = 'post' action = 'Usuario_view.php'>
            <input  type = "hidden" name = "idUsuario">                    
    </form>  

    <script language = "javascript">
        function fun_delete(pid){
            respuesta = confirm('esta seguro?');
            if(respuesta){
                document.fdelete.idUsuario.value = pid;
                document.fdelete.submit();
            }
        } 
        function fun_view(pid){
            document.fview.idUsuario.value = pid;
            document.fview.submit();
        }                             
    </script>

</body>

</html>

<?php 
  include("../includes/footer.php");
	include("../bd/fin_conexion.php");
?>