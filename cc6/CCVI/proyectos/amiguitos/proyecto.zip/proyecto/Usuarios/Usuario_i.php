<?php
	include("../bd/inicia_conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<div align="center">
		<?php

                $sql = "insert into Usuario (usuario, contrasena, idRol) values ('" . $_POST["usuario"] . "'";
                $sql = $sql .", md5('" . $_POST["contrasena"] . "')";
                $sql = $sql .", " . $_POST["idRol"] . ")";

                $resultado = mysqli_query($con, $sql);	
               // echo $sql;
                if($resultado){
                   // echo "funciono";
                   header("location:ListUsuario.php?variable=1");
                }else{
                    echo "no funciono";
                }

				//echo "Interes Registrado con éxito.<br /><a href='index.html'>Continuar</a>";		
			
		?>
	</div>
</body>
</html>
<?php 
	include("../bd/fin_conexion.php");
?>