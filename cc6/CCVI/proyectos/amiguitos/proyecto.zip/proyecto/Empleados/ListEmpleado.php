<?php
  include("../bd/inicia_conexion.php");
  include("../includes/header.php");
?>
  

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->

          <h1 class="h3 mb-2 text-gray-800">Empleados</h1>
         

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
          <?php
            if (!empty($_GET)) {
              $variable=$_GET['variable'];
              if($variable ==1){
               $_POST["nombre"] = "";
               $_POST["apellido"] = "";
               $_POST["dpi"] = "";
               $_POST["email"] = "";
              echo '<div class="card-header py-3">
                      <h6 class="m-0 font-weight-bold text-primary">EMPLEADO CREADO CON EXITO!</h6>
                    </div>';
              }
            }            
          ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Nombres</th>
                      <th>Apellidos</th>
                      <th>DPI</th>
                      <th>Email</th>
                      <th>Departamento</th>
                      <th>Puesto</th>
                      <th>Oficina</th>
                      <th>Ext Telefonica</th>
                      <th>Modificar</th>
                      <th>Eliminar</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Id</th>
                      <th>Nombres</th>
                      <th>Apellidos</th>
                      <th>DPI</th>
                      <th>Email</th>
                      <th>Departamento</th>
                      <th>Puesto</th>
                      <th>Oficina</th>
                      <th>Ext Telefonica</th>
                      <th>Modificar</th>
                      <th>Eliminar</th>
                    </tr>
                  </tfoot>
                  <tbody>
                       <?php 
                        
                                $sql = "select  e.idEmpleado, e.nombre as nombre, e.apellido, e.dpi, e.email, d.nombre as departamento";   
                                $sql = $sql . ", p.nombre as puesto, o.nombre as oficina, o.telefono as telefono";  
                                $sql = $sql . " FROM Empleado e inner join Departamento d on e.idDepartamento = d.idDepartamento";
                                $sql = $sql . " inner join Puesto p  on e.idPuesto = p.idPuesto";   
                                $sql = $sql . " inner join Oficina o  on e.idOficina = o.idOficina"; 
                                $sql = $sql . " WHERE e.idempleado != 1 and e.nombre like '%" . $_POST["nombre"] . "%'"; 
                                $sql = $sql . " and e.apellido like '%" . $_POST["apellido"] . "%'";
                                $sql = $sql . " and e.dpi like '%" . $_POST["dpi"] . "%'";
                                $sql = $sql . " and e.email like '%" . $_POST["email"] . "%'";
                                if(!empty($_POST["idDepartamento"])){
                                  if($_POST["idDepartamento"] != "-1"){
                                    $sql = $sql . " and e.idDepartamento = " . $_POST["idDepartamento"];
                                  }
                                }
                                if(!empty($_POST["idPuesto"])){
                                  if($_POST["idPuesto"] != "-1"){
                                    $sql = $sql . " and e.idPuesto = " . $_POST["idPuesto"];
                                  }
                                }
                                if(!empty($_POST["idOficina"])){
                                  if($_POST["idOficina"] != "-1"){
                                    $sql = $sql . " and e.idOficina = " . $_POST["idOficina"];
                                  }
                                }

                               // echo $sql;
                                $resultado = mysqli_query($con, $sql);
                                while ($fila = mysqli_fetch_array($resultado)) {
                                    echo "<tr>";
                                    echo "<td>" . $fila["idEmpleado"] . "</td>";
                                    echo "<td>" . $fila["nombre"] . "</td>";
                                    echo "<td>" . $fila["apellido"] . "</td>";
                                    echo "<td>" . $fila["dpi"] . "</td>";
                                    echo "<td>" . $fila["email"] . "</td>";
                                    echo "<td>" . $fila["departamento"] . "</td>";
                                    echo "<td>" . $fila["puesto"] . "</td>";
                                    echo "<td>" . $fila["oficina"] . "</td>";
                                    echo "<td>" . $fila["telefono"] . "</td>";
                                    if ($_SESSION["idRol"] == "3" ){
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                    }else{
                                    echo "<td align = 'center'>";
                                    echo "<a href = 'javascript:fun_view(" . $fila["idEmpleado"] . ");'>";   
                                    echo "<i class=\"fas fa-pencil-alt\"></i>";                                                   
                                    echo "</td>";
                                    echo "<td align = 'center'>";
                                    echo "<a href = 'javascript:fun_delete(" . $fila["idEmpleado"] . ");'>";
                                    echo "<i class=\"fas fa-trash-alt\"></i>";
                                    echo "</td>";
                                    echo "</tr>";      
                                    }                             
								                }
							            ?>                
                  </tbody>
                </table>
              </div>
            </div>
          </div>

            


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

  <form name = 'fdelete' method = 'post' action = 'Empleado_d.php'>
            <input  type = "hidden" name = "idEmpleado">                    
    </form>    
    <form name = 'fview' method = 'post' action = 'Empleado_view.php'>
            <input  type = "hidden" name = "idEmpleado">                    
    </form>  

    <script language = "javascript">
        function fun_delete(pid){
            respuesta = confirm('esta seguro?');
            if(respuesta){
                document.fdelete.idEmpleado.value = pid;
                document.fdelete.submit();
            }
        } 
        function fun_view(pid){
            document.fview.idEmpleado.value = pid;
            document.fview.submit();
        }                             
    </script>

</body>

</html>

<?php 
  include("../includes/footer.php");
	include("../bd/fin_conexion.php");
?>