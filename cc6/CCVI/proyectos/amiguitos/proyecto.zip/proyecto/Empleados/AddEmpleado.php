<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
$mensaje = "";
$habilitador = "";
if ($_SESSION["idRol"] == "3" ){
    $habilitador = "disabled";
    $mensaje = "Usted no tiene permisos para editar información...";
}
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Agregar Empleado</h1>

        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->
        <div>
            <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row width="100%" align="center">
                    <div class="col-lg-7">
                        <div class="p-5">
                        <div class="text-left">
                            <h1 class="h5 text-gray-900 mb-4">Por favor llene el siguiente formulario:</h1>
                        </div>
                        <form name="datos" method="post" action="Empleado_i.php" onsubmit="return verifica_formulario(this);">
                            <div class="col-sm-6">
                              <input type="text"  class="form-control form-control-user" name="nombre" placeholder="Nombres del Empleado" required>
                              <br>
                              <input type="text" class="form-control form-control-user" name="apellido" placeholder="Apellidos del Empleado" required>
                              <br>
                              <input type="number" maxlength="13" minlength="13" class="form-control form-control-user" name="dpi" placeholder="DPI del Empleado" required>
                              <label >formato: 1234567890123</label>
                              <br>
                              <input type="email" class="form-control form-control-user" name="email" placeholder="Email del Empleado" required>
                              <br>
                              <label >Departamento:</label>
                              <select class="browser-default custom-select" name="idDepartamento">
                                <option value="-1" selected></option>
                                <?php 
                                  $sql = "select  *from Departamento where idDepartamento != 1";
                                  $resultado = mysqli_query($con, $sql);
                                  while ($fila = mysqli_fetch_array($resultado)) {
                                    $seleccionado = "";
                                    if ($idDepartamento == $fila["idDepartamento"]){
                                      $seleccionado = "selected";
                                    }
                                    echo "<option value='" . $fila["idDepartamento"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                  }
                                ?>
                              </select>
                              <br>
                              <label >Puesto:</label>
                              <select class="browser-default custom-select" name="idPuesto">
                                <option value="-1" selected></option>
                                <?php 
                                  $sql = "select  *from Puesto where idPuesto != 1";
                                  $resultado = mysqli_query($con, $sql);
                                  while ($fila = mysqli_fetch_array($resultado)) {
                                    $seleccionado = "";
                                    if ($idPuesto == $fila["idPuesto"]){
                                      $seleccionado = "selected";
                                    }
                                    echo "<option value='" . $fila["idPuesto"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                  }
                                ?>
                              </select>
                              <br>
                             <label >Oficina:</label>
                              <select class="browser-default custom-select" name="idOficina">
                                <option value="-1" selected></option>
                                <?php 
                                  $sql = "select  *from oficina where idOficina != 1";
                                  $resultado = mysqli_query($con, $sql);
                                  while ($fila = mysqli_fetch_array($resultado)) {
                                    $seleccionado = "";
                                    if ($idOficina == $fila["idOficina"]){
                                      $seleccionado = "selected";
                                    }
                                    echo "<option value='" . $fila["idOficina"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                  }
                                ?>
                              </select>
                              <br>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Crear Empleado" <?= $habilitador; ?>>
                            <br>
                            <label ><?= $mensaje; ?></label>

                        </form>               
                    </div>
                </div>
            </div>
            </div>

        </div>
        <!-- Termina Formulario  -->

       

      <!-- End of Main Content -->

      <?PHP
include("../includes/footer.php");
?>

<script type="text/javascript">
	function verifica_formulario(pform) {
		if (pform.idDepartamento.value == -1) {
			alert('Debe de seleccionar un departamento');
			pform.idDepartamento.focus();
			return false;
		}
    if (pform.idPuesto.value == -1) {
			alert('Debe de seleccionar un puesto');
			pform.idPuesto.focus();
			return false;
		}
    if (pform.idOficina.value == -1) {
			alert('Debe de seleccionar una oficina');
			pform.idOficina.focus();
			return false;
		}
		return true;
	}
</script>
<?PHP
include("../bd/fin_conexion.php");
?>

