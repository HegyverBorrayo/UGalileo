<?php
	include("../bd/inicia_conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<div align="center">
		<?php

                $sql = "insert into Empleado (nombre, apellido, dpi, email, idDepartamento, idPuesto, idOficina) values ('" . $_POST["nombre"] . "'";
                $sql = $sql .", '" . $_POST["apellido"] . "'";
                $sql = $sql .", '" . $_POST["dpi"] . "'";
                $sql = $sql .", '" . $_POST["email"] . "'";
                $sql = $sql .", " . $_POST["idDepartamento"] . "";
                $sql = $sql .", " . $_POST["idPuesto"] . "";
                $sql = $sql .", " . $_POST["idOficina"] . ")";
                $resultado = mysqli_query($con, $sql);	
               // echo $sql;
                if($resultado){
                   // echo "funciono";
                   header("location:ListEmpleado.php?variable=1");
                }else{
                    echo "no funciono";
                }

				//echo "Interes Registrado con éxito.<br /><a href='index.html'>Continuar</a>";		
			
		?>
	</div>
</body>
</html>
<?php 
	include("../bd/fin_conexion.php");
?>