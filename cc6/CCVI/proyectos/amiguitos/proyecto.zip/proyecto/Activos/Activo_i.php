<?php
	include("../bd/inicia_conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<div align="center">
		<?php

                $sql = "insert into activo (nombre, depreciacion, valor, fecha, idEmpleado, idMarca, idTipo,idEstado,idProveedor,idTipoPago) values ('" . $_POST["nombre"] . "'";
                $sql = $sql .", " . $_POST["depreciacion"];
                $sql = $sql .", " . $_POST["valor"];
                $sql = $sql .", '" . $_POST["fecha"] . "'";
                $sql = $sql .", " . $_POST["idEmpleado"];
                $sql = $sql .", " . $_POST["idMarca"];
                $sql = $sql .", " . $_POST["idTipo"];
                $sql = $sql .", " . $_POST["idEstado"] ;
                $sql = $sql .", " . $_POST["idProveedor"] ;
                $sql = $sql .", " . $_POST["idTipoPago"] . ")";
                $resultado = mysqli_query($con, $sql);	
               //

               $sql = "insert into Historial (fecha, idEmpleado, idActivo) values (NOW()";
               $sql = $sql .", " . $_POST["idEmpleado"];
               $sql = $sql .", (SELECT max(idActivo) id from Activo))";
                echo $sql; 
               $resultado = mysqli_query($con, $sql);	
                if($resultado){
                   // echo "funciono";
                   header("location:ListActivo.php?variable=1");
                }else{
                    echo "no funciono";
                }

				//echo "Interes Registrado con éxito.<br /><a href='index.html'>Continuar</a>";		
			
		?>
	</div>
</body>
</html>
<?php 
	include("../bd/fin_conexion.php");
?>