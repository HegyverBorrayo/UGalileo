<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
$mensaje = "";
$habilitador = "";
if ($_SESSION["idRol"] == "3" ){
    $habilitador = "disabled";
    $mensaje = "Usted no tiene permisos para editar información...";
}
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Registrar Activo</h1>

        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->
        <div>
            <div class="card o-hidden border-0 shadow-lg my-5">
              <div class="card-body p-0">
                  <!-- Nested Row within Card Body -->
                  <div class="row width="100%" align="center">
                      <div class="col-lg-10">
                          <div class="p-5">
                          <div class="text-left">
                              <h1 class="h5 text-gray-900 mb-4">Por favor llene el siguiente formulario:</h1>
                          </div>
                          <form name="datos" method="post" action="Activo_i.php" onsubmit="return verifica_formulario(this);">
                            <div class="col-sm-6">                             
                              <div class="text-left">
                                <h2 class="h6 text-gray-700 mb-4">Datos del Activo:</h2>
                                <input type="text"  class="form-control form-control-user" name="nombre" placeholder="Descripción" required>
                                <br>
                                <label >Tipo:</label>
                                <select class="browser-default custom-select" name="idTipo">
                                  <option value="-1" selected></option>
                                  <?php 
                                    $sql = "select  *from Tipo where idTipo != 1";
                                    $resultado = mysqli_query($con, $sql);
                                    while ($fila = mysqli_fetch_array($resultado)) {
                                      $seleccionado = "";
                                      if ($idTipo == $fila["idTipo"]){
                                        $seleccionado = "selected";
                                      }
                                      echo "<option value='" . $fila["idTipo"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                    }
                                  ?>
                                </select>
                                <br>
                                <label >Marca:</label>
                                <select class="browser-default custom-select" name="idMarca">
                                  <option value="-1" selected></option>
                                  <?php 
                                    $sql = "select  *from Marca where idMarca != 1";
                                    $resultado = mysqli_query($con, $sql);
                                    while ($fila = mysqli_fetch_array($resultado)) {
                                      $seleccionado = "";
                                      if ($idMarca == $fila["idMarca"]){
                                        $seleccionado = "selected";
                                      }
                                      echo "<option value='" . $fila["idMarca"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                    }
                                  ?>
                                </select>
                                <br>
                                <label >Estado:</label>
                                <select class="browser-default custom-select" name="idEstado">
                                  <option value="-1" selected></option>
                                  <?php 
                                    $sql = "select  *from Estado where idEstado != 1";
                                    $resultado = mysqli_query($con, $sql);
                                    while ($fila = mysqli_fetch_array($resultado)) {
                                      $seleccionado = "";
                                      if ($idEstado == $fila["idEstado"]){
                                        $seleccionado = "selected";
                                      }
                                      echo "<option value='" . $fila["idEstado"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                    }
                                  ?>
                                </select>
                                <br>
                                <hr>
                                <h2 class="h6 text-gray-700 mb-4">Responsable:</h2>
                                <br>
                                <label >Departamento:</label>
                                <select class="browser-default custom-select" name="idDepartamento" id="idDepartamento">
                                  <option value="-1" selected></option>
                                  <?php 
                                    $sql = "select  *from Departamento where idDepartamento != 1";
                                    $resultado = mysqli_query($con, $sql);
                                    while ($fila = mysqli_fetch_array($resultado)) {
                                      $seleccionado = "";
                                      if ($idDepartamento == $fila["idDepartamento"]){
                                        $seleccionado = "selected";
                                      }
                                      echo "<option value='" . $fila["idDepartamento"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                    }
                                  ?>
                                </select>
                                <label >Primer responsable:</label>
                                <select class="browser-default custom-select" name="idEmpleado" id="idEmpleados" >
                                 
                                </select>
                                <hr>
                                <h2 class="h6 text-gray-700 mb-4">Datos de la compra:</h2>
                                <input type="number" min="0" class="form-control form-control-user" name="valor" placeholder="Valor de la compra" required>
                                <br>
                                <label >Fecha de la compra:</label>
                                <input type="date" class="form-control form-control-user" name="fecha" required>
                                <br>
                                <input type="number" min="0" max="100" class="form-control form-control-user" name="depreciacion" placeholder="Depreciación Anual (%)" required>
                                <br>
                                <label >Tipo de pago:</label>
                                <select class="browser-default custom-select" name="idTipoPago">
                                  <option value="-1" selected></option>
                                  <?php 
                                    $sql = "select  *from TipoPago where idTipoPago";
                                    $resultado = mysqli_query($con, $sql);
                                    while ($fila = mysqli_fetch_array($resultado)) {
                                      $seleccionado = "";
                                      if ($idTipoPago == $fila["idTipoPago"]){
                                        $seleccionado = "selected";
                                      }
                                      echo "<option value='" . $fila["idTipoPago"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                    }
                                  ?>
                                </select>
                                <br>
                                <label >Proveedor:</label>
                                <select class="browser-default custom-select" name="idProveedor">
                                  <option value="-1" selected></option>
                                  <?php 
                                    $sql = "select  *from Proveedor where idProveedor != 1";
                                    $resultado = mysqli_query($con, $sql);
                                    while ($fila = mysqli_fetch_array($resultado)) {
                                      $seleccionado = "";
                                      if ($idProveedor == $fila["idProveedor"]){
                                        $seleccionado = "selected";
                                      }
                                      echo "<option value='" . $fila["idProveedor"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                    }
                                  ?>
                                </select>
                              </div>
                              </div>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Crear Activo" <?= $habilitador; ?>>
                            <br>
                            <label ><?= $mensaje; ?></label>
                            <br>
                            <label ></label>
                          </form>                                       
                      </div>                     
                  </div>
              </div>             
            </div>

        </div>
        <!-- Termina Formulario  -->
      <!-- End of Main Content -->

      <?PHP
include("../includes/footer.php");
?>

<script type="text/javascript">
  $varo = "select  *from Empleado where idEmpleado != 1";

   $("#idEmpleado").change();

	function verifica_formulario(pform) {
    if (pform.idTipo.value == -1) {
			alert('Debe de seleccionar un Tipo de activo');
			pform.idTipo.focus();
			return false;
		}
		if (pform.idMarca.value == -1) {
			alert('Debe de seleccionar una Marca');
			pform.idMarca.focus();
			return false;
		}
    if (pform.idEstado.value == -1) {
			alert('Debe de seleccionar un Estado');
			pform.idEstado.focus();
			return false;
		}
    if (pform.idEmpleado.value == -1) {
			alert('Debe de seleccionar un primer resposable');
			pform.idEmpleado.focus();
			return false;
		}
    if (pform.idTipoPago.value == -1) {
			alert('Debe de seleccionar un tipo de pago');
			pform.idTipoPago.focus();
			return false;
		}
    if (pform.idProveedor.value == -1) {
			alert('Debe de seleccionar un proveedor');
			pform.idProveedor.focus();
			return false;
		}
		return true;
	}


  $("#idEmpleado").change();
  $.ajax({
        type: 'POST',
        url: 'methods.php/getEmpleados',
        data: {'pst': 0}
      })
      .done(function(msg){
        
        $('#idEmpleados').html(msg);
      })
      .fail(function(){
        alert('Hubo un errror al cargar las listas_rep');
      })

      $("#idDepartamento").on("change",function(){
        $('#idEmpleados').empty();
    var data = $('#idDepartamento').val();
    $.ajax({
        type: 'POST',
        url: 'methods.php/getEmpleadosid',
        data: {'id': data, 'pst': 1}
      })
      .done(function(msg){

        $('#idEmpleados').html(msg);
      })
      .fail(function(){
        alert('Hubo un errror al cargar las listas_rep');
      });
  });

</script>
<?PHP
include("../bd/fin_conexion.php");
?>

