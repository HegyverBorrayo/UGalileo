<?PHP
include("../bd/inicia_conexion.php");

$sql = "select a.*,e.idDepartamento from Activo a inner join Empleado e on a.idEmpleado = e.idEmpleado ";
$sql = $sql . " where idActivo = " . $_POST["idActivo"];
$resultado = mysqli_query($con, $sql);
while ($fila = mysqli_fetch_array($resultado)) {
    $nombre = $fila["nombre"];
    $depreciacion = $fila["depreciacion"];
    $valor = $fila["valor"];
    $fecha = $fila["fecha"];
    $idEmpleado = $fila["idEmpleado"];
    $idMarca = $fila["idMarca"];
    $idTipo = $fila["idTipo"];
    $idEstado = $fila["idEstado"];
    $idEstadoActual = $fila["idEstado"];
    $idProveedor = $fila["idProveedor"];
    $idTipoPago = $fila["idTipoPago"];		
    $idDepartamento = $fila["idDepartamento"];	
}
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Detalles Activo Fijo</h1>

        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->
        <div>
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row width="100%" align="center">
                        <div class="col-lg-10">
                            <div class="p-5">
                            <div class="text-left">
                                <h1 class="h5 text-gray-900 mb-4">Edite los campos que desee</h1>
                            </div>
                            <form name="datos" method="post" action="Activo_u.php" onsubmit="return verifica_formulario(this);">
                                <div class="col-sm-6">                              	
                                  <div class="text-left">
                                    <?php if($idEstado == 2){
                                       echo "<input type=\"hidden\" name=\"idEstado\" value=\"<?=$idEstado;?>\">";
                                       } ?>
                                    <input type="hidden" name="idActivo" value="<?=$_POST["idActivo"];?>">
                                    <input type="hidden" name="EmpleadoActual" id="EmpleadoActual" value="<?=$idEmpleado;?>">
                                      <h2 class="h5 text-gray-700 mb-4">Datos del Activo:</h2>
                                      <label align = "left">Descripción:</label>
                                      <input type="text"  class="form-control form-control-user" name="nombre" value="<?=$nombre;?>" required>
                                      <br>
                                      <label >Tipo:</label>
                                      <select class="browser-default custom-select" name="idTipo">
                                        <option value="-1" selected></option>
                                        <?php 
                                          $sql = "select  *from Tipo where idTipo != 1";
                                          $resultado = mysqli_query($con, $sql);
                                          while ($fila = mysqli_fetch_array($resultado)) {
                                            $seleccionado = "";
                                            if ($idTipo == $fila["idTipo"]){
                                              $seleccionado = "selected";
                                            }
                                            echo "<option value='" . $fila["idTipo"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                          }
                                        ?>
                                      </select>
                                      <br>
                                      <label >Marca:</label>
                                      <select class="browser-default custom-select" name="idMarca">
                                        <option value="-1" selected></option>
                                        <?php 
                                          $sql = "select  *from Marca where idMarca != 1";
                                          $resultado = mysqli_query($con, $sql);
                                          while ($fila = mysqli_fetch_array($resultado)) {
                                            $seleccionado = "";
                                            if ($idMarca == $fila["idMarca"]){
                                              $seleccionado = "selected";
                                            }
                                            echo "<option value='" . $fila["idMarca"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                          }
                                        ?>
                                      </select>
                                      <br>
                                      <label >Estado:</label>
                                      

                                      <select class="browser-default custom-select" name="idEstado">
                                        <option value="-1" selected></option>
                                        <?php             
                                         
                                          $sql = "select  *from Estado where idEstado != 1";
                                          if($idEstado == 2){ $sql = "select  *from Estado where idEstado = 2";}  
                                          $resultado = mysqli_query($con, $sql);
                                          while ($fila = mysqli_fetch_array($resultado)) {
                                            $seleccionado = "";
                                            if ($idEstado == $fila["idEstado"]){
                                              $seleccionado = "selected";
                                            }
                                            echo "<option value='" . $fila["idEstado"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                          }
                                        ?>
                                      </select>
                                      <?php 
                                        if($idEstado == 2)
                                          { echo "<label >Para editar el estado debe realizarse un mantenimiento al activo.</label>";} 
                                      ?>
                                      <br>
                                      <hr>
                                      <h2 class="h5 text-gray-700 mb-4">Responsable:</h2>
                                      <label >Departamento:</label>
                                      <select class="browser-default custom-select" name="idDepartamento" id="idDepartamento">
                                        <option value="-1" selected></option>
                                        <?php 
                                          $sql = "select  *from Departamento where idDepartamento != 1";
                                          $resultado = mysqli_query($con, $sql);
                                          while ($fila = mysqli_fetch_array($resultado)) {
                                            $seleccionado = "";
                                            if ($idDepartamento == $fila["idDepartamento"]){
                                              $seleccionado = "selected";
                                            }
                                            echo "<option value='" . $fila["idDepartamento"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                          }
                                        ?>
                                      </select>
                                      <label >Primer responsable:</label>
                                      <select class="browser-default custom-select" name="idEmpleado" id="idEmpleados" >
                                      
                                      </select>
                                      <hr>
                                      <h2 class="h5 text-gray-700 mb-4">Datos de la compra:</h2>
                                      <label align = "left">Valor (Q):</label>
                                      <input type="number" min="0" class="form-control form-control-user" name="valor"  value="<?=$valor;?>" required>
                                      <br>
                                      <label >Fecha de la compra:</label>
                                      <input type="date" class="form-control form-control-user" name="fecha" value="<?=$fecha;?>" required>
                                      <br>
                                      <label >Depreciación Anual (%):</label>
                                      <input type="number" min="0" max="100" class="form-control form-control-user" name="depreciacion" value="<?=$depreciacion;?>" required>
                                      <br>
                                      <label >Tipo de pago:</label>
                                      <select class="browser-default custom-select" name="idTipoPago">
                                        <option value="-1" selected></option>
                                        <?php 
                                          $sql = "select  *from TipoPago where idTipoPago";
                                          $resultado = mysqli_query($con, $sql);
                                          while ($fila = mysqli_fetch_array($resultado)) {
                                            $seleccionado = "";
                                            if ($idTipoPago == $fila["idTipoPago"]){
                                              $seleccionado = "selected";
                                            }
                                            echo "<option value='" . $fila["idTipoPago"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                          }
                                        ?>
                                      </select>
                                      <br>
                                      <label >Proveedor:</label>
                                      <select class="browser-default custom-select" name="idProveedor">
                                        <option value="-1" selected></option>
                                        <?php 
                                          $sql = "select  *from Proveedor where idProveedor != 1";
                                          $resultado = mysqli_query($con, $sql);
                                          while ($fila = mysqli_fetch_array($resultado)) {
                                            $seleccionado = "";
                                            if ($idProveedor == $fila["idProveedor"]){
                                              $seleccionado = "selected";
                                            }
                                            echo "<option value='" . $fila["idProveedor"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
                                          }
                                        ?>
                                      </select>  
                                                                     
                                  </div>      
                                </div>
                                <br> 
                                <input type="submit" class="btn btn-primary" value="Editar Activo">
                            </form>                                     
                        </div>
                        
                    </div>
                    
                </div>
                <h1 class="h3 mb-2 text-gray-800">Historial de traspasos del activo:</h1>

<!-- DataTales Example -->
 <div class="card shadow mb-4">
       <div class="card-body">
         <div class="table-responsive">
           <table class="table table-bordered" id="dataTable"  cellspacing="10">
             <thead>
               <tr>
                 <th>Fecha de asignación</th>
                 <th>Responsable</th>
                 <th>Departamento</th>                       
               </tr>
             </thead>
             <tfoot>
               <tr>
                 <th>Fecha de asignación</th>
                 <th>Responsable</th>
                 <th>Departamento</th>
               </tr>
             </tfoot>
             <tbody>
                 <?php                           
                           $sql = "select h.fecha, e.nombre as Responsable, d.nombre as Departamento from historial h inner join empleado e on h.idempleado = e.idEmpleado inner join Departamento d on e.idDepartamento = d.idDepartamento ";    
                           $sql = $sql . " WHERE h.idActivo = " . $_POST["idActivo"]; 
                         // echo $sql;
                           $resultado = mysqli_query($con, $sql);
                           while ($fila = mysqli_fetch_array($resultado)) {
                               echo "<tr>";
                               echo "<td>" . $fila["fecha"] . "</td>";
                               echo "<td>" . $fila["Responsable"] . "</td>";
                               echo "<td>" . $fila["Departamento"] . "</td>";
                               echo "</tr>";                                   
                           }
                     ?>                
             </tbody>
           </table>
         </div>
       </div>
   </div>
            </div>
        </div>
        <!-- Termina Formulario  -->



        </div>                            
      <!-- End of Main Content -->

      <?PHP
include("../includes/footer.php");
?>

<script type="text/javascript">
  $varo = "select  *from Empleado where idEmpleado != 1";

   $("#idEmpleado").change();

	function verifica_formulario(pform) {
    if (pform.idTipo.value == -1) {
			alert('Debe de seleccionar un Tipo de activo');
			pform.idTipo.focus();
			return false;
		}
		if (pform.idMarca.value == -1) {
			alert('Debe de seleccionar una Marca');
			pform.idMarca.focus();
			return false;
		}
    if (pform.idEstado.value == -1) {
			alert('Debe de seleccionar un Estado');
			pform.idEstado.focus();
			return false;
		}
    if (pform.idEmpleado.value == -1) {
			alert('Debe de seleccionar un primer resposable');
			pform.idEmpleado.focus();
			return false;
		}
    if (pform.idTipoPago.value == -1) {
			alert('Debe de seleccionar un tipo de pago');
			pform.idTipoPago.focus();
			return false;
		}
    if (pform.idProveedor.value == -1) {
			alert('Debe de seleccionar un proveedor');
			pform.idProveedor.focus();
			return false;
		}
		return true;
	}

  var emp = $('#EmpleadoActual').val();
  $.ajax({
    type: 'POST',
    url: 'methods.php/getEmpleados',
    data: {'pst': 0,'idEmpleado': emp}
  })
  .done(function(msg){
    
    $('#idEmpleados').html(msg);
  })
  .fail(function(){
    alert('Hubo un errror al cargar las listas_rep');
  })

  $("#idDepartamento").on("change",function(){
    $('#idEmpleados').empty();
  var data = $('#idDepartamento').val();
  var emp = $('#EmpleadoActual').val();
  //console.log(data);
  //alert(emp);
  $.ajax({
      type: 'POST',
      url: 'methods.php/getEmpleadosid',
      data: {'id': data, 'pst': 1,'idEmpleado': emp}
    })
    .done(function(msg){

      $('#idEmpleados').html(msg);
    })
    .fail(function(){
      alert('Hubo un errror al cargar las listas_rep');
    });
    });


</script>

<?PHP

include("../bd/fin_conexion.php");
?>

