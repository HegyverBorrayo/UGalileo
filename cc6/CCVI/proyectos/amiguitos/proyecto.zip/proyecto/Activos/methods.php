<?PHP
function getEmpleados(){

  //var_dump($_POST["idEmpleado"]);

 // var_dump(!empty($_POST["idEmpleado"]));
  if(!empty($_POST["idEmpleado"])){
      $idEmpleado = $_POST['idEmpleado'];
    }
    //var_dump($idEmpleado);
  $sql = 'select  * from Empleado where idEmpleado != 1';
  $con = mysqli_connect("127.0.0.1", "root", "");
  mysqli_select_db($con, "ActivosFijos");
  $resultado = mysqli_query($con, $sql);
  $empleados = ' <option value="-1" ></option>';
  while ($fila = mysqli_fetch_array($resultado)) {
   $seleccionado = "";
   //var_dump($fila["idEmpleado"]);
   //var_dump($idEmpleado == $fila["idEmpleado"]);
   if ($idEmpleado == $fila["idEmpleado"]){

       $seleccionado = "selected";
   }

   var_dump($seleccionado);
   $empleados .= "<option value='" . $fila["idEmpleado"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";

   //echo $empleados;
 }
 mysqli_close($con);
 return $empleados;
}




function getEmpleadosid(){

  //dd($_POST["idEmpleado"]);

  if(!empty($_POST["idEmpleado"])){
    $idEmpleado = $_POST['idEmpleado'];
  }
  
  
    $id = $_POST['id'];
    $sql = 'select  * from Empleado where idEmpleado != 1 and idDepartamento = ' .  $id;

    $con = mysqli_connect("127.0.0.1", "root", "");
    mysqli_select_db($con, "ActivosFijos");

    $resultado = mysqli_query($con, $sql);
   $empleados = ' <option value="-1" selected></option>';
   while ($fila = mysqli_fetch_array($resultado)) {
     $seleccionado = "";
     if ($idEmpleado == $fila["idEmpleado"]){
         $seleccionado = "selected";
     }
     $empleados .= "<option value='" . $fila["idEmpleado"] . "' ". $seleccionado .">" . $fila["nombre"] . "</option>";
   }
   mysqli_close($con);
  return $empleados;
  
  }

  $pst = $_POST['pst'];

  if ($pst == 1){

    echo getEmpleadosid();

  }else{

    echo getEmpleados();
  }

 

?>
