<?php
  include("../bd/inicia_conexion.php");
  include("../includes/header.php");
?>
  

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->

          <h1 class="h3 mb-2 text-gray-800">Activos Fijos</h1>
         

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <?php
              if (!empty($_GET)) {
                $variable=$_GET['variable'];
                if($variable ==1){
                $_POST["nombre"] = "";
                $_POST["minimoValor"] = "0";
                $_POST["maximoValor"] = "(SELECT MAX(valor) from activo)";
                $_POST["minimoDepreciacion"] = "0";
                $_POST["maximoDepreciacion"] = "100";
                echo '<div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">ACTIVO CREADO CON EXITO!</h6>
                      </div>';
                }
              }            
            ?>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                      <tr>
                        <th>Id</th>
                        <th>Descripción</th>
                        <th>Tipo</th>
                        <th>Marca</th>
                        <th>Responsable</th>
                        <th>Valor(Q)</th>
                        <th>Fecha de Compra</th>
                        <th>Proveedor</th>
                        <th>Tipo de Pago</th>
                        <th>Estado</th>
                        <th>Ver Detalles</th>
                        <th>Eliminar</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                      <th>Id</th>
                        <th>Descripción</th>
                        <th>Tipo</th>
                        <th>Marca</th>
                        <th>Responsable</th>
                        <th>Valor(Q)</th>
                        <th>Fecha de Compra</th>
                        <th>Proveedor</th>
                        <th>Tipo de Pago</th>
                        <th>Estado</th>
                        <th>Ver Detalles</th>
                        <th>Eliminar</th>
                      </tr>
                    </tfoot>
                    <tbody>
                        <?php 
                          
                                  $sql = "select a.idActivo, a.nombre as descripcion, t.nombre as tipo, m.nombre as marca, e.nombre as responsable, a.valor, a.fecha, p.nombre as proveedor, tp.nombre as TipoPago, es.nombre as estado";   
                                  $sql = $sql . " from activo a inner join empleado e on a.idEmpleado = e.idEmpleado ";  
                                  $sql = $sql . " inner join marca m on a.idMarca = m.idMarca inner join tipo t on a.idTipo = t.idTipo  inner join estado es on a.idEstado = es.idEstado";
                                  $sql = $sql . " inner join tipopago tp on a.idTipoPago = tp.idTipoPago inner join proveedor p on a.idProveedor =  p.idProveedor";   
                                  $sql = $sql . " WHERE a.nombre like '%" . $_POST["nombre"] . "%'"; 
                                  $sql = $sql . " and (valor BETWEEN " . $_POST["minimoValor"];
                                  $sql = $sql . " and " . $_POST["maximoValor"] . ")";
                                  if (!empty($_GET)) {
                                    if($variable !=1){
                                      $sql = $sql . " and (fecha BETWEEN '" . $_POST["minimoFecha"];
                                      $sql = $sql . "' and '" . $_POST["maximoFecha"] . "')";
                                    }
                                  }  
                                  $sql = $sql . " and (depreciacion BETWEEN " . $_POST["minimoDepreciacion"];
                                  $sql = $sql . " and " . $_POST["maximoDepreciacion"] . ")";
                                  if(!empty($_POST["idTipo"])){
                                    if($_POST["idTipo"] != "-1"){
                                      $sql = $sql . " and a.idTipo = " . $_POST["idTipo"];
                                    }
                                  }
                                  if(!empty($_POST["idDepartamento"])){
                                    if($_POST["idDepartamento"] != "-1"){
                                      $sql = $sql . " and e.idDepartamento = " . $_POST["idDepartamento"];
                                    }
                                  }
                                  if(!empty($_POST["idMarca"])){
                                    if($_POST["idMarca"] != "-1"){
                                      $sql = $sql . " and a.idMarca = " . $_POST["idMarca"];
                                    }
                                  }
                                  if(!empty($_POST["idEstado"])){
                                    if($_POST["idEstado"] != "-1"){
                                      $sql = $sql . " and a.idEstado = " . $_POST["idEstado"];
                                    }
                                  }
                                  if(!empty($_POST["idEmpleado"])){
                                    if($_POST["idEmpleado"] != "-1"){
                                      $sql = $sql . " and a.idEmpleado = " . $_POST["idEmpleado"];
                                    }
                                  }
                                  if(!empty($_POST["idTipoPago"])){
                                    if($_POST["idTipoPago"] != "-1"){
                                      $sql = $sql . " and a.idTipoPago = " . $_POST["idTipoPago"];
                                    }
                                  }
                                  if(!empty($_POST["idProveedor"])){
                                    if($_POST["idProveedor"] != "-1"){
                                      $sql = $sql . " and a.idProveedor = " . $_POST["idProveedor"];
                                    }
                                  }
                                  //echo $sql;
                                  $resultado = mysqli_query($con, $sql);
                                  while ($fila = mysqli_fetch_array($resultado)) {
                                      echo "<tr>";
                                      echo "<td>" . $fila["idActivo"] . "</td>";
                                      echo "<td>" . $fila["descripcion"] . "</td>";
                                      echo "<td>" . $fila["tipo"] . "</td>";
                                      echo "<td>" . $fila["marca"] . "</td>";
                                      echo "<td>" . $fila["responsable"] . "</td>";
                                      echo "<td>" . $fila["valor"] . "</td>";
                                      echo "<td>" . $fila["fecha"] . "</td>";
                                      echo "<td>" . $fila["proveedor"] . "</td>";
                                      echo "<td>" . $fila["TipoPago"] . "</td>";
                                      echo "<td>" . $fila["estado"] . "</td>";
                                      if ($_SESSION["idRol"] == "3" ){
                                        echo "<td>Usted no tiene permisos para editar información</td>";
                                        echo "<td>Usted no tiene permisos para editar información</td>";
                                      }else{
                                      echo "<td align = 'center'>";
                                      echo "<a href = 'javascript:fun_view(" . $fila["idActivo"] . ");'>"; 
                                      echo "<i class=\"fas fa-search\"></i>";                                                   
                                      echo "</td>";
                                      echo "<td align = 'center'>";
                                      echo "<a href = 'javascript:fun_delete(" . $fila["idActivo"] . ");'>";
                                      echo "<i class=\"fas fa-trash-alt\"></i>";
                                      echo "</td>";
                                      echo "</tr>";    
                                      }                               
                                  }
                            ?>                
                    </tbody>
                  </table>
                </div>
              </div>
          </div>

            


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

    <form name = 'fdelete' method = 'post' action = 'Activo_d.php'>
            <input  type = "hidden" name = "idActivo">                    
    </form>    
    <form name = 'fview' method = 'post' action = 'Activo_view.php'>
            <input  type = "hidden" name = "idActivo">                    
    </form>  

    <script language = "javascript">
        function fun_delete(pid){
            respuesta = confirm('ADVERTENCIA: Si elimina el activo fijo, se eliminaran todo su historial, todos sus mantenimientos y esta acción no se puede revertir. ¿Desea continuar?');
            if(respuesta){
                document.fdelete.idActivo.value = pid;
                document.fdelete.submit();
            }
        } 
        function fun_view(pid){
            document.fview.idActivo.value = pid;
            document.fview.submit();
        }                             
    </script>

</body>

</html>

<?php 
  include("../includes/footer.php");
	include("../bd/fin_conexion.php");
?>