<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Activo Editado</h1>
          <?php
            $sql = "begin transacction";
            $resultado = mysqli_query($con, $sql);

            $sql = "update Activo set";
            $sql = $sql . " nombre = '". $_POST["nombre"] ."'";
            $sql = $sql . ", depreciacion = '". $_POST["depreciacion"] ."'";
            $sql = $sql . ", valor = '". $_POST["valor"] ."'";
            $sql = $sql . ", fecha = '". $_POST["fecha"] ."'";
            $sql = $sql . ", idEmpleado = '". $_POST["idEmpleado"] ."'";
            $sql = $sql . ", idMarca = '". $_POST["idMarca"] ."'";
            $sql = $sql . ", idTipo = '". $_POST["idTipo"] ."'";
            $sql = $sql . ", idEstado = '". $_POST["idEstado"] ."'";
            $sql = $sql . ", idProveedor = '". $_POST["idProveedor"] ."'";
            $sql = $sql . ", idTipoPago = '". $_POST["idTipoPago"] ."'";
            $sql = $sql . " where idActivo = ". $_POST["idActivo"] ."";	
           // echo $sql;		
            $resultado = mysqli_query($con, $sql);

            $sql = "commit";
            $resultado = mysqli_query($con, $sql);	

            if($_POST["idEmpleado"] != $_POST["EmpleadoActual"]){
              $sql = "insert into historial (fecha, idEmpleado, idActivo) values (now()";
              $sql = $sql .", " . $_POST["idEmpleado"];
              $sql = $sql .", " . $_POST["idActivo"] . ")";
              $resultado = mysqli_query($con, $sql);
            }

            
          ?>
        <a href = "Activo_busqueda.php">nueva busqueda</a>
        </div>
        <!-- /.container-fluid -->
      <!-- End of Main Content -->

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

