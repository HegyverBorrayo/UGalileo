<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Puesto Editado</h1>
          <?php
			$sql = "begin transacction";
			$resultado = mysqli_query($con, $sql);

			$sql = "update Puesto set";
			$sql = $sql . " nombre = '". $_POST["nombre"] ."'";
            $sql = $sql . " where idPuesto = ". $_POST["idPuesto"] ."";	
          //  echo $sql;		
			$resultado = mysqli_query($con, $sql);

			$sql = "commit";
			$resultado = mysqli_query($con, $sql);	

			
		?>
        <a href = "Puesto_busqueda.php">nueva busqueda</a>
        </div>
        <!-- /.container-fluid -->


       

      <!-- End of Main Content -->

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

