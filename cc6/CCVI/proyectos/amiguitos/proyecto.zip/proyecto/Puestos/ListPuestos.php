<?php
  include("../bd/inicia_conexion.php");
  include("../includes/header.php");
?>
  <!-- Custom styles for this page -->
  <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->

          <h1 class="h3 mb-2 text-gray-800">Puestos</h1>
         

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
          <?php
            if (!empty($_GET)) {
              $variable=$_GET['variable'];
              if($variable ==1){
                $_POST["nombre"] = "";
              echo '<div class="card-header py-3">
                      <h6 class="m-0 font-weight-bold text-primary">OFICINA CREADA CON EXITO!</h6>
                    </div>';
              }
            }            
          ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Nombre</th>
                      <th>Modificar</th>
                      <th>Eliminar</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Id</th>
                      <th>Nombre</th>
                      <th>Modificar</th>
                      <th>Eliminar</th>
                    </tr>
                  </tfoot>
                  <tbody>
                       <?php 
                                $sql = "select  * from Puesto where idPuesto != 1";
                                $sql = $sql . " and nombre like '%" . $_POST["nombre"] . "%'"; 
                                $resultado = mysqli_query($con, $sql);
                               // echo $sql;
                                while ($fila = mysqli_fetch_array($resultado)) {
                                    echo "<tr>";
                                    echo "<td>" . $fila["idPuesto"] . "</td>";
                                    echo "<td>" . $fila["nombre"] . "</td>";
                                    if ($_SESSION["idRol"] == "3" ){
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                      echo "<td>Usted no tiene permisos para editar información</td>";
                                    }else{
                                    echo "<td align = 'center'>";
                                    echo "<a href = 'javascript:fun_view(" . $fila["idPuesto"] . ");'>";   
                                    echo "<i class=\"fas fa-pencil-alt\"></i>";                                                   
                                    echo "</td>";
                                    echo "<td align = 'center'>";
                                    echo "<a href = 'javascript:fun_delete(" . $fila["idPuesto"] . ");'>";
                                    echo "<i class=\"fas fa-trash-alt\"></i>";
                                    echo "</td>";
                                    echo "</tr>";   
                                    }                                
								                }
							            ?>                
                  </tbody>
                </table>
              </div>
            </div>
          </div>

            


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->



  <form name = 'fdelete' method = 'post' action = 'Puesto_d.php'>
            <input  type = "hidden" name = "idPuesto">                    
    </form>    
    <form name = 'fview' method = 'post' action = 'Puesto_view.php'>
            <input  type = "hidden" name = "idPuesto">                    
    </form>  

    <script language = "javascript">
        function fun_delete(pid){
            respuesta = confirm('esta seguro?');
            if(respuesta){
                document.fdelete.idPuesto.value = pid;
                document.fdelete.submit();
            }
        } 
        function fun_view(pid){
            document.fview.idPuesto.value = pid;
            document.fview.submit();
        }                             
    </script>


<?php 
  include("../includes/footer.php");
	include("../bd/fin_conexion.php");
?>