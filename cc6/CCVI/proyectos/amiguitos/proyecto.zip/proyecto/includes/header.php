<?php 
  session_start();
  if (!isset($_SESSION["usuario"]) || !isset($_SESSION["idRol"]) || !isset($_SESSION["idUsuario"])){
    header('Location: ../login.php');
  }
?>

<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Activos Fijos</title>

  <!-- Custom fonts for this template -->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

      <!-- Sidebar -->
      <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
  <div class="sidebar-brand-icon ">
    <i class="fas fa-jedi"></i>
  </div>
  <div class="sidebar-brand-text mx-3">Activos Fijos <sup>BETA</sup></div>   <!-- titulo-->
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Inicia Menu lateral  -->
<li class="nav-item ">
  <a class="nav-link" href="../index.php">
    <i class="fas fa-home"></i>
    <span>Inicio</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
  Control Empresarial
</div>

<!-- Control Empresarial -->

<!-- Nav Item - Oficinas -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesOficinas" aria-expanded="true" aria-controls="collapseUtilities">
    <i class="far fa-building"></i>
    <span>Oficinas</span>
  </a>
  <div id="OpcionesOficinas" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Oficinas/Oficina_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Oficinas/AddOficina.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>

<!-- Nav Item - Departamentos -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesDep" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-briefcase"></i>
    <span>Departamentos</span>
  </a>
  <div id="OpcionesDep" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Departamentos/Departamento_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Departamentos/AddDepartamento.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>   

<!-- Nav Item - Puestos -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesPuestos" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-network-wired"></i>
    <span>Puestos</span>
  </a>
  <div id="OpcionesPuestos" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Puestos/Puesto_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Puestos/AddPuesto.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>    

<!-- Nav Item - Empleados -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesEmp" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-user-circle"></i>
    <span>Empleados</span>
  </a>
  <div id="OpcionesEmp" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Empleados/Empleado_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Empleados/AddEmpleado.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li> 

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Control de Activos -->
<div class="sidebar-heading">
  Control de Activos Fijos
</div>
<!-- Nav Item - Estados -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesEstados" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-check-circle"></i>
    <span>Estados</span>
  </a>
  <div id="OpcionesEstados" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Estados/Estado_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Estados/AddEstado.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li> 
<!-- Nav Item - Tipos -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesTipos" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-edit"></i>
    <span>Tipos</span>
  </a>
  <div id="OpcionesTipos" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Tipos/Tipo_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Tipos/AddTipo.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li> 
<!-- Nav Item - Proveedores -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesProveedores" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-industry"></i>
    <span>Proveedores</span>
  </a>
  <div id="OpcionesProveedores" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Proveedores/Proveedor_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Proveedores/AddProveedor.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>       
<!-- Nav Item - Marcas -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesMarcas" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fab fa-xbox"></i>
    <span>Marcas</span>
  </a>
  <div id="OpcionesMarcas" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Marcas/Marca_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Marcas/AddMarca.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>   
<!-- Nav Item - Activos -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesActivos" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-desktop"></i>
    <span>Activos Fijos</span>
  </a>
  <div id="OpcionesActivos" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Activos/Activo_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Activos/AddActivo.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>   
<!-- Nav Item - Mantenimientos -->
<li class="nav-item">
  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesMantenimientos" aria-expanded="true" aria-controls="collapseUtilities">
  <i class="fas fa-tools"></i>
    <span>Mantenimientos</span>
  </a>
  <div id="OpcionesMantenimientos" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Opciones:</h6>
      <a class="collapse-item" href="../Mantenimientos/Mantenimiento_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
      <a class="collapse-item" href="../Mantenimientos/AddMantenimiento.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
    </div>
  </div>
</li>    

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block" >
      <div class="sidebar-heading" <?php if($_SESSION['idRol'] != "1" ) { echo " style=\"display:none;\"";} ?> >
        Control de Usuarios
      </div>
      <!-- Nav Item - Usuarios -->
      <li class="nav-item" <?php if($_SESSION['idRol'] != "1" ) { echo " style=\"display:none;\"";} ?> >
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#OpcionesUsuarios" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-users-cog"></i>
          <span>Usuarios</span>
        </a>
        <div id="OpcionesUsuarios" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Opciones:</h6>
            <a class="collapse-item" href="../Usuarios/Usuario_busqueda.php"> <i class="fas fa-stream"></i>&nbsp Buscar</a>
            <a class="collapse-item" href="../Usuarios/AddUsuario.php"> <i class="fas fa-plus"></i>&nbsp Agregar</a>
          </div>
        </div>
      </li>    

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
  <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- Termina menu lateral -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

  <!-- Inicia Barra superior -->
  <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
      <i class="fa fa-bars"></i>
    </button>



    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">

      <!-- Nav Item - User Information -->
      <!-- Nav Item - User Information -->
      <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['usuario']; ?></span>
                <img class="img-profile rounded-circle" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQQ6JZT1nmPJTaSV9loAME1dZGvACdRwO7lc50P-tYSgABmB1PQ&usqp=CAU">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
    </ul>

  </nav>
  <!-- Termina Barra superior -->

  