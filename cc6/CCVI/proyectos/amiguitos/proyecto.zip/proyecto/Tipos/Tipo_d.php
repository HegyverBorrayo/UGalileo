<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Tipo eliminado</h1>
          <?php
                        $sql1 = "update Activo set idTipo = 1 where idTipo = " . $_POST["idTipo"];	
                        $resultado1 = mysqli_query($con, $sql1);

			$sql1 = "delete from Tipo where idTipo = " . $_POST["idTipo"];	
			$resultado1 = mysqli_query($con, $sql1);
		?>
        <a href = "Tipo_busqueda.php">nueva busqueda</a>
        </div>
 

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

