<?php
	include("../bd/inicia_conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>LAB2020</title>
</head>
<body>
	<div align="center">
		<?php

                $sql = "insert into Tipo (nombre) values ('" . $_POST["nombre"] . "')";
                echo $sql;
                $resultado = mysqli_query($con, $sql);	
                if($resultado){
                   // echo "funciono";
                   header("location:listTipo.php?variable=1");
                }else{
                    echo "no funciono";
                }				
		?>
	</div>
</body>
</html>
<?php 
	include("../bd/fin_conexion.php");
?>