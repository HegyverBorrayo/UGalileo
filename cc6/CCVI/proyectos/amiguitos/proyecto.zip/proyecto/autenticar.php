<?PHP
include("./bd/inicia_conexion.php");
	
	session_start();
	
	$usuario = str_replace("'","",$_POST["usuario"]);
	$contrasena = str_replace("'","\'",$_POST["contrasena"]);
	$usuario_valido = 0;
	$sql="select idUsuario, usuario, idRol from usuario";
	$sql=$sql." where usuario = '". $usuario ."' and contrasena = md5('".$contrasena."')";
	$resultado = mysqli_query($con,$sql);
    //echo $sql;
	while($fila = mysqli_fetch_array($resultado))
	{
		$usuario_valido = 1;
        $idUsuario = $fila["idUsuario"];
        $usuario = $fila["usuario"];
        $idRol = $fila["idRol"];
	}
    
	if($usuario_valido == 1){
		$_SESSION["usuario"] = $usuario;
        $_SESSION["idUsuario"] = $idUsuario;
        $_SESSION["idRol"] = $idRol;
        
        echo $_SESSION["usuario"];
		header('Location: index.php');
	} else {
		header('Location: login.php?error=1');
	}
	

include("./bd/fin_conexion.php");
?>