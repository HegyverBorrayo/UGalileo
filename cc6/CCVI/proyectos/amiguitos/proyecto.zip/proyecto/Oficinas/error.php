<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Error, la información de esa oficina ya existe.</h1>

        <a href = "AddOficina.php">intentar de nuevo</a>
        </div>
 

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

