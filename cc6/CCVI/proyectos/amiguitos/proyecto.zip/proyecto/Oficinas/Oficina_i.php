<?php
	include("../bd/inicia_conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>LAB2020</title>
</head>
<body>
	<div align="center">
        <?php
          $sql = "select count(nombre) as conteo from Oficina where nombre = '" . $_POST["nombre"] . "'";
          $sql = $sql ." OR telefono = '" . $_POST["telefono"] . "'";
          echo $sql;
          $resultado = mysqli_query($con, $sql);
          while ($fila = mysqli_fetch_array($resultado)) {
            $Conteo = $fila["conteo"];   
          }


          if($Conteo > 0){
            header("location:error.php");
          }else{
            $sql = "insert into Oficina (nombre, telefono) values ('" . $_POST["nombre"] . "'";
            $sql = $sql .", '" . $_POST["telefono"] . "')";
            $resultado = mysqli_query($con, $sql);	
            if($resultado){
                echo "funciono";
               header("location:listOficinas.php?variable=1");
            }else{
                echo "no funciono";
            } 
          }


			//	echo "Interes Registrado con éxito.<br /><a href='index.html'>Continuar</a>";		
			
		?>
	</div>
</body>
</html>
<?php 
	include("../bd/fin_conexion.php");
?>