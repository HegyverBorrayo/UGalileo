<?PHP
include("../bd/inicia_conexion.php");
include("../includes/header.php");
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Departamento eliminado</h1>
          <?php
            $sql1 = "update Empleado set idDepartamento = 1 where idDepartamento = " . $_POST["idDepartamento"];	
            $resultado1 = mysqli_query($con, $sql1);

            $sql1 = "delete from Departamento where idDepartamento = " . $_POST["idDepartamento"];	
            $resultado1 = mysqli_query($con, $sql1);
          ?>
        <a href = "Departamento_busqueda.php">nueva busqueda</a>
        </div>
        <!-- /.container-fluid -->

        <!-- Inicia Formulario  -->

        <!-- Termina Formulario  -->

       

      <!-- End of Main Content -->

<?PHP
include("../includes/footer.php");
include("../bd/fin_conexion.php");
?>

