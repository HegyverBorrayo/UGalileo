<?PHP
   $cURL = curl_init();
   $url="http://127.0.0.1:8080/bdd/ws_pais.php";
   curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($cURL, CURLOPT_URL, $url);
   curl_setopt($cURL, CURLOPT_HTTPGET, true);
   $result = curl_exec($cURL);
   curl_close($cURL);
   $json = json_decode($result, true);
   foreach($json as $item) 
    { 
    	$pais = $item['pais']; 
        $nombre = $item['nombre']; 
        echo "id pais " . $pais . '<br>';
        echo "nombre " . $nombre . '<br>';
        echo "<hr width='100%'>";
   }
?>