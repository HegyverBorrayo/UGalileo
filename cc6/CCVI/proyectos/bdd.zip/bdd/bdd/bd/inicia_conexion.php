<?PHP
  $con = mysqli_connect("localhost","lab2020v2","12345678");
  if (!$con)
  {
   die('Could not connect: ' . mysqli_connect_error());
  }
  mysqli_select_db($con, "lab2020");
  mysqli_set_charset($con,"utf8");
?>