<?PHP
	mysqli_close($con);
?>