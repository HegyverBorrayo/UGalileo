<?PHP
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: *');
    header('Content-type: application/json; charset=utf-8');
    include("./bd/inicia_conexion.php");    

	     echo "[";
	     $i=0;
	     $sql="select pais, nombre, gentilicio from pais ";
	     $sql= $sql . " order by nombre";
             $resultado = mysqli_query($con, $sql);
             while ($fila = mysqli_fetch_array($resultado))
	     {
		if ($i >0)
                {
		   echo ",";
		}
		echo '{"pais":"' . $fila["pais"] . '", "nombre":"' . $fila["nombre"] . '", "gentilicio":"' . $fila["gentilicio"] . '"}';
		$i++;
	     }
	     echo "]";

	include("./bd/fin_conexion.php");
?>